Workflow figure assets
Generated with Python/Matplotlib